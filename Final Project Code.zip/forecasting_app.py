from flask import Flask, request, render_template_string
import pandas as pd
import pickle
from datetime import datetime
import pytz

#Load models
with open(r"C:\Users\Peasa\Desktop\Final\all_station_prophet_models.pkl", "rb") as f:
    station_models = pickle.load(f)

station_list = sorted(station_models.keys())
app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    forecast_result = None
    selected_station = ""
    hours = 24
    error = False

    if request.method == "POST":
        selected_station = request.form.get("station")
        hours = int(request.form.get("hours", 24))

        if selected_station in station_models:
            model = station_models[selected_station]

            #Get NY time
            ny_tz = pytz.timezone("America/New_York")
            now = datetime.now(ny_tz)
            future_dates = pd.date_range(start=now, periods=hours, freq='h', tz=ny_tz)
            future = pd.DataFrame({'ds': future_dates.tz_localize(None)})
            forecast = model.predict(future)

            #Make it easier to interpret for the user
            forecast['ds'] = pd.to_datetime(forecast['ds']).dt.tz_localize('UTC').dt.tz_convert('America/New_York')
            forecast_result = forecast[["ds", "yhat"]].copy()
            forecast_result.columns = ["Date & Time (New York)", "Predicted Rides"]
            forecast_result["Date & Time (New York)"] = forecast_result["Date & Time (New York)"].dt.strftime("%b %d, %Y — %I:%M %p")
            forecast_result["Predicted Rides"] = forecast_result["Predicted Rides"].round(2)
        else:
            forecast_result = "Station not found"
            error = True

    return render_template_string("""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Citi Bike Forecast</title>
            <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; }
                select, input { width: 300px; padding: 8px; }
                h1 { color: #333; }
                table { margin-top: 20px; border-collapse: collapse; }
                th, td { padding: 8px 12px; border: 1px solid #ccc; text-align: left; }
            </style>
        </head>
        <body>
            <h1>Forecast Citi Bike Demand</h1>
            <form method="post">
                <label>Select Station:</label><br>
                <select name="station" id="station-select">
                    {% for station in stations %}
                        <option value="{{ station }}" {% if station == selected_station %}selected{% endif %}>{{ station }}</option>
                    {% endfor %}
                </select><br><br>

                <label>Forecast Horizon (hours):</label><br>
                <input type="number" name="hours" value="{{ hours }}" min="1" max="168"><br><br>

                <input type="submit" value="Generate Forecast">
            </form>

            {% if forecast_result is not none %}
                <h2>Forecast for: {{ selected_station }}</h2>
                {% if error %}
                    <p style="color:red;">Station not found.</p>
                {% else %}
                    {{ forecast_result.to_html(index=False) | safe }}
                {% endif %}
            {% endif %}

            <script>
                $(document).ready(function() {
                    $('#station-select').select2({
                        placeholder: "Select or search for a station",
                        width: 'resolve'
                    });
                });
            </script>
        </body>
        </html>
    """, stations=station_list, forecast_result=forecast_result, selected_station=selected_station, hours=hours, error=error)

if __name__ == "__main__":
    app.run(debug=True)
