import pandas as pd
from pathlib import Path

folder = Path(r"C:\Users\Peasa\Desktop\Final\citibike data")
csv_files = sorted(folder.glob("*.csv"))

output_file = "CitiBike2023_Combined_Sampled.csv"
sample_size = 12500  #500,000 / 40
first = True

for f in csv_files:
    print(f"Sampling from {f.name}...")
    df = pd.read_csv(f, low_memory=False)
    if len(df) >= sample_size:
        sample = df.sample(n=sample_size, random_state=42)
    else:
        sample = df
    sample.to_csv(output_file, mode='w' if first else 'a', index=False, header=first)
    first = False

print("Sample saved to CitiBike2023_Combined_Sampled.csv")
