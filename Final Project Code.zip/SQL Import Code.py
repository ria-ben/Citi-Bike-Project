import os
import pandas as pd
from glob import glob
from sqlalchemy import create_engine

engine = create_engine("postgresql+psycopg2://postgres:31@localhost:5432/CitiBike2023")

folder_path = r"C:\Users\Peasa\Desktop\Final\Citibike data"
csv_files = glob(os.path.join(folder_path, "*.csv"))

for file in csv_files:
    print(f"Importing: {file}")
    df = pd.read_csv(file, low_memory=False)
    df.to_sql("citibike_trips", engine, if_exists="append", index=False, method="multi")

print("All files imported successfully.")
